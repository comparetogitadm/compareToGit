package org;

public class Class1 {
	
	public void do() {
		System.out.println("hello");
	}

}